-- AlterTable
ALTER TABLE "user" ADD COLUMN     "isValidated" BOOLEAN NOT NULL DEFAULT false;
