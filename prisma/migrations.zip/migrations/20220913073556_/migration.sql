-- DropIndex
DROP INDEX "pickup_location_booking_id_key";
